# STM32F4-discovery-lcd
Will display a jumping cat on the tft-lcd display

Demo: https://youtu.be/Gf3_FKm4Bx8
