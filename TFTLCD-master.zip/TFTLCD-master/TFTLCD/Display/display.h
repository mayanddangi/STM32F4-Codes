#include "stm32f4xx_hal.h"
#include <stdlib.h>
#include "main.h"

void Display_Menu(void);
void Display_Text(void);
void Display_Picture(void);
void Display_Color_Picture(void);
